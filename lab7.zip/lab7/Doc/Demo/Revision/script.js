// var x =10
// var y=2
// function add(a,b){
    
// }

// console.log(fun())//Error
// var fun = function(){
//     return 'hello'
// }


// w = 10


/**
 * custom
 * built-in
 * bom(window
 * document)
 * DOM
 */















